import pymongo
from datetime import datetime
from bson.objectid import ObjectId

client = pymongo.MongoClient("mongodb://localhost:27017/")
db = client["mydb"]
ibids = db["ibids"]

def get_day_ahead_bids():
    return list(ibids.find({"bid_round": "Day-Ahead"}))

def calculate_cumulative(bid_price, bid_value):
    total_price = sum(bid_price)
    total_value = sum(bid_value)
    return total_price, total_value

def match_bids(bid_docs):
    # Simplified logic: Match one producer with one consumer per time slot
    producers = [doc for doc in bid_docs if "PRO" in doc["infrastructure_id"]]
    consumers = [doc for doc in bid_docs if "CON" in doc["infrastructure_id"]]
    stabilizers = [doc for doc in bid_docs if "STAB" in doc["infrastructure_id"]]

    for hour in range(24):
        for p_doc in producers:
            p_val = p_doc["bid_value"][hour]
            if p_val == 0:
                continue

            matched = False
            for c_doc in consumers:
                c_val = c_doc["bid_value"][hour]
                if c_val > 0:
                    # Match min(p_val, c_val)
                    match_val = min(p_val, c_val)
                    price = (p_doc["bid_price"][hour] + c_doc["bid_price"][hour]) / 2

                    # Update Allocated and Price in both documents
                    update_bid_allocation(p_doc, hour, match_val, price)
                    update_bid_allocation(c_doc, hour, match_val, price)

                    p_doc["bid_value"][hour] -= match_val
                    c_doc["bid_value"][hour] -= match_val

                    matched = True
                    break

            if not matched:
                # Assign remaining value to Stabilizer
                for s_doc in stabilizers:
                    update_bid_allocation(s_doc, hour, p_val, 0)
                    break  # Assign once per hour

def update_bid_allocation(doc, hour, alloc_val, price_val):
    bid_updates = doc.get("bid_updates", [])
    if not bid_updates:
        return
    update_block = bid_updates[0]

    # Update Allocated and Price
    update_block["Allocated"][hour] += alloc_val
    update_block["Price"][hour] = price_val

    # Update timestamp
    update_block["timestamp"] = datetime.utcnow()
    doc["last_updated"] = datetime.utcnow()

    # Save to DB
    ibids.update_one(
        {"_id": doc["_id"]},
        {"$set": {
            "bid_updates": bid_updates,
            "last_updated": doc["last_updated"]
        }}
    )

def main():
    print("[*] Fetching bids...")
    bid_docs = get_day_ahead_bids()

    for doc in bid_docs:
        price_total, value_total = calculate_cumulative(doc["bid_price"], doc["bid_value"])
        print(f"Infra: {doc['infrastructure_id']} - Price: {price_total}, Value: {value_total}")

    print("[*] Matching bids...")
    match_bids(bid_docs)

    print("[✓] Bid allocation and updates completed.")

if __name__ == "__main__":
    main()
