import socket
import json
import re
from pymongo import MongoClient
from datetime import datetime

# -----------------------
# MongoDB Setup
# -----------------------
client = MongoClient("mongodb://localhost:27017/")
db = client["mydb"]
data_collection = db["Real-Time Infrastructure Data"]
controlsamples_collection = db["controlsamples"]

def get_latest_control_bits():
    """Retrieve the most recent control_bits from the controlsamples collection."""
    doc = controlsamples_collection.find_one(sort=[("timestamp", -1)])
    if doc and "control_bits" in doc:
        return doc["control_bits"]
    return 0

# -----------------------
# TCP Server Setup
# -----------------------
HOST = ''          # Listen on all network interfaces
PORT = 12345       # TCP port

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((HOST, PORT))
server_socket.listen(5)
print(f"✅ TCP Server is listening on port {PORT}...")

def process_data(data_str, client_ip):
    """
    Process the incoming sensor data string and insert a document in the
    "Real-Time Infrastructure Data" collection.

    Expected formats:
      - "V:<voltage>,C:<current>"
      - "ID:<deviceId>;V:<voltage>,C:<current>"
    """
    data_str = data_str.strip()
    device_id = "INF1001"  # default device id if not provided

    if data_str.startswith("ID:"):
        try:
            parts = data_str.split(';')
            id_part = parts[0]
            device_id = id_part[3:].strip()
            if len(parts) > 1:
                data_str = parts[1].strip()
            else:
                print(f⚠️ No sensor data provided after device ID from {client_ip}: {data_str}")
                return False
        except Exception as e:
            print(f"❌ Error parsing device ID from {client_ip}: {e}")
            return False

    if not (data_str.startswith("V:") and ",C:" in data_str):
        print(f"⚠️ Ignoring invalid message from {client_ip}: {data_str}")
        return False

    try:
        match = re.match(r"V:([\d\.\-]+),C:([\d\.\-]+)", data_str)
        if not match:
            print(f"❌ Failed to parse message: {data_str}")
            return False
        voltage = float(match.group(1))
        current = float(match.group(2))
        timestamp = datetime.utcnow().isoformat() + "Z"

        control_bits = get_latest_control_bits()
        status = "Active" if (control_bits & 1) else "Qualified-Inactive"

        document = {
            "infrastructure_id": device_id,
            "real_time_data": {
                "status": status,
                "data_timestamp": timestamp,
                "voltage": voltage,
                "current": current
            }
        }
        result = data_collection.insert_one(document)
        print(f"📦 Stored document for {device_id} with id: {result.inserted_id}")
        return True
    except Exception as e:
        print(f"❌ Error processing data from {client_ip}: {e}")
        return False

def generate_control_message():
    """Create a control message using the latest control_bits."""
    control_bits = get_latest_control_bits()
    return {
        "control_bits": control_bits,
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }

# -----------------------
# Main Server Loop
# -----------------------
try:
    while True:
        conn, addr = server_socket.accept()
        client_ip = addr[0]
        print(f"🔌 Connected by {addr}")
        with conn:
            while True:
                data = conn.recv(1024)
                if not data:
                    print(f"⛔ Client {addr} disconnected")
                    break

                message = data.decode('utf-8').strip()
                print(f"📨 Received from {client_ip}: {message}")

                if process_data(message, client_ip):
                    control_msg = generate_control_message()
                    response = f"controlsample:{control_msg['control_bits']}\n"
                    conn.sendall(response.encode('utf-8'))
                    print(f"📤 Sent control message: {response.strip()}")
                else:
                    error_response = "error: invalid data format\n"
                    conn.sendall(error_response.encode('utf-8'))
except KeyboardInterrupt:
    print("\n🛑 Server is shutting down.")
finally:
    server_socket.close()
