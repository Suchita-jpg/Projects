const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const net = require('net');
const path = require('path');

const app = express();
const webServerPort = 3001; // For web UI
const tcpServerPort = 4000; // For NodeMCU TCP connection

// Create Express HTTP server for web UI
const webServer = http.createServer(app);
const io = socketIo(webServer);

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

// Route for the Edge Node UI
app.get('/edge_connected', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start the Express server
webServer.listen(webServerPort, () => {
  console.log(`Express web server listening on port ${webServerPort}`);
});

// ----- TCP Server for NodeMCU Connection -----
// Use an array to support multiple NodeMCU connections
let nodeMcuSockets = [];

const tcpServer = net.createServer((socket) => {
  console.log(`NodeMCU connected from ${socket.remoteAddress}:${socket.remotePort}`);
  nodeMcuSockets.push(socket);

  socket.on('data', (data) => {
    console.log(`Received from NodeMCU: ${data.toString()}`);
    // Broadcast sensor data to all connected web clients via Socket.IO
    io.emit('sensorData', data.toString());
  });

  socket.on('close', () => {
    console.log('NodeMCU disconnected');
    nodeMcuSockets = nodeMcuSockets.filter(s => s !== socket);
  });

  socket.on('error', (err) => {
    console.error(`TCP Socket Error: ${err}`);
  });
});

tcpServer.listen(tcpServerPort, () => {
  console.log(`TCP server listening on port ${tcpServerPort}`);
});

// ----- Socket.IO: Handle Web Client Connections -----
io.on('connection', (socket) => {
  console.log('Web client connected via Socket.IO');

  // When a command is received from the UI, forward it to all connected NodeMCUs via TCP.
  socket.on('sendCommand', (command) => {
    console.log(`Command from UI: ${command}`);
    if (nodeMcuSockets.length > 0) {
      nodeMcuSockets.forEach((nodeSocket) => {
        nodeSocket.write(command + '\n');
      });
    } else {
      console.log('No NodeMCU connected to send command.');
    }
  });
});
