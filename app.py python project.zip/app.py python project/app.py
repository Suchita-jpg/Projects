import sys
import pandas as pd
import pickle
from PyQt5.QtWidgets import (
    QApplication, QWidget, QLabel, QPushButton, QVBoxLayout,
    QComboBox, QLineEdit, QTextEdit, QMessageBox, QTabWidget, QFormLayout
)

class DiseasePredictor:
    def __init__(self):
        with open("trained_model.pkl", "rb") as f:
            self.model = pickle.load(f)
        with open("disease_labels.pkl", "rb") as f:
            self.disease_labels = pickle.load(f)

    def predict(self, symptoms):
        input_vector = [1 if symptom in symptoms else 0 for symptom in self.disease_labels["symptoms"]]
        prediction = self.model.predict([input_vector])[0]
        return self.disease_labels["diseases"][prediction]

class HistoryManager:
    def __init__(self):
        self.history_file = "patient_history.csv"
        try:
            self.df = pd.read_csv(self.history_file)
        except FileNotFoundError:
            self.df = pd.DataFrame(columns=["Name", "Age", "Gender", "Symptoms", "Prediction", "Doctor"])

    def save(self, name, age, gender, symptoms, prediction, doctor):
        new_row = {
            "Name": name, "Age": age, "Gender": gender,
            "Symptoms": ", ".join(symptoms),
            "Prediction": prediction, "Doctor": doctor
        }
        self.df = pd.concat([self.df, pd.DataFrame([new_row])], ignore_index=True)
        self.df.to_csv(self.history_file, index=False)

    def get_history(self):
        return self.df.to_string(index=False)

class MediPredictApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("MediPredict: Healing Starts Here")
        self.setGeometry(100, 100, 600, 400)

        self.predictor = DiseasePredictor()
        self.history_manager = HistoryManager()

        self.tabs = QTabWidget()
        self.tabs.addTab(self.create_prediction_tab(), "Predict Disease")
        self.tabs.addTab(self.create_booking_tab(), "Book Appointment")
        self.tabs.addTab(self.create_history_tab(), "Patient History")

        layout = QVBoxLayout()
        layout.addWidget(self.tabs)
        self.setLayout(layout)

    def create_prediction_tab(self):
        tab = QWidget()
        layout = QFormLayout()

        self.name_input = QLineEdit()
        self.age_input = QLineEdit()
        self.gender_input = QComboBox()
        self.gender_input.addItems(["Male", "Female", "Other"])

        self.symptom_input = QLineEdit()
        self.result_output = QTextEdit()
        self.result_output.setReadOnly(True)

        predict_btn = QPushButton("Predict Disease")
        predict_btn.clicked.connect(self.handle_prediction)

        layout.addRow("Name:", self.name_input)
        layout.addRow("Age:", self.age_input)
        layout.addRow("Gender:", self.gender_input)
        layout.addRow("Enter Symptoms (comma separated):", self.symptom_input)
        layout.addRow(predict_btn)
        layout.addRow("Prediction Result:", self.result_output)

        tab.setLayout(layout)
        return tab

    def handle_prediction(self):
        name = self.name_input.text()
        age = self.age_input.text()
        gender = self.gender_input.currentText()
        symptoms = [s.strip() for s in self.symptom_input.text().split(",") if s.strip()]

        if not name or not age or not symptoms:
            QMessageBox.warning(self, "Input Error", "Please fill all fields and enter symptoms.")
            return

        prediction = self.predictor.predict(symptoms)
        self.predicted_disease = prediction
        self.collected_data = (name, age, gender, symptoms, prediction)
        self.result_output.setText(f"Predicted Disease: {prediction}")

    def create_booking_tab(self):
        tab = QWidget()
        layout = QFormLayout()

        self.doctor_dropdown = QComboBox()
        self.doctor_dropdown.addItems(["Dr. Smith (Physician)", "Dr. Patel (Dermatologist)",
                                       "Dr. Rao (Cardiologist)", "Dr. Khan (Neurologist)"])

        book_btn = QPushButton("Book Appointment")
        book_btn.clicked.connect(self.book_appointment)

        layout.addRow("Select Doctor:", self.doctor_dropdown)
        layout.addRow(book_btn)

        tab.setLayout(layout)
        return tab

    def book_appointment(self):
        try:
            name, age, gender, symptoms, prediction = self.collected_data
        except AttributeError:
            QMessageBox.warning(self, "No Prediction", "Please predict disease first.")
            return

        doctor = self.doctor_dropdown.currentText()
        self.history_manager.save(name, age, gender, symptoms, prediction, doctor)
        QMessageBox.information(self, "Success", f"Appointment booked with {doctor} for {name}.")

    def create_history_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()

        self.history_output = QTextEdit()
        self.history_output.setReadOnly(True)
        self.refresh_history()

        refresh_btn = QPushButton("Refresh History")
        refresh_btn.clicked.connect(self.refresh_history)

        layout.addWidget(self.history_output)
        layout.addWidget(refresh_btn)

        tab.setLayout(layout)
        return tab

    def refresh_history(self):
        history = self.history_manager.get_history()
        self.history_output.setText(history if history.strip() else "No history available.")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MediPredictApp()
    window.show()
    sys.exit(app.exec_())
