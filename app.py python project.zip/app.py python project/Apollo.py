import sys
import csv
from datetime import datetime
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QPushButton, QLabel, QTextEdit, QTabWidget, 
                             QLineEdit, QMessageBox, QTableWidget, 
                             QTableWidgetItem, QListWidget, QComboBox)
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt

# Base Entity Class
class BaseEntity:
    def __init__(self, name):
        self.name = name

# Health Entity Class
class HealthEntity(BaseEntity):
    def __init__(self, name):
        super().__init__(name)

# Disease Class
class Disease(HealthEntity):
    def __init__(self, name, symptoms, medicine, safe_days):
        super().__init__(name)
        self.symptoms = symptoms
        self.medicine = medicine
        self.safe_days = safe_days

    def predict(self, user_symptoms):
        match_count = sum(1 for symptom in user_symptoms if symptom in self.symptoms)
        return match_count >= len(self.symptoms) * 0.2  # 20% threshold

    def get_recommendation(self, days):
        recommendation = f"Medicine: {self.medicine}\n"
        if days > self.safe_days:
            recommendation += f"Symptoms persist beyond {self.safe_days} days. Please consult a doctor."
        return recommendation

# Doctor Class
class Doctor(HealthEntity):
    def __init__(self, name, specialty):
        super().__init__(name)
        self.specialty = specialty

# Patient Data Manager
class PatientData:
    def __init__(self, filename="patient_data.csv"):
        self.filename = filename
        self.create_csv_if_not_exists()

    def create_csv_if_not_exists(self):
        try:
            with open(self.filename, 'r') as f:
                pass
        except FileNotFoundError:
            with open(self.filename, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(["Patient Name", "Disease", "Date", "Appointment Doctor", "Appointment Date", "Appointment Time"])

    def add_disease(self, patient_name, disease):
        with open(self.filename, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([patient_name, disease, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "", "", ""])

    def add_appointment(self, patient_name, doctor, date, time):
        with open(self.filename, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([patient_name, "", datetime.now().strftime("%Y-%m-%d %H:%M:%S"), doctor, date, time])

    def get_history(self, patient_name):
        history = []
        with open(self.filename, 'r') as f:
            reader = csv.reader(f)
            next(reader)  # Skip header
            for row in reader:
                if row[0] == patient_name:
                    history.append(row)
        return history

# Health App Class
class HealthApp:
    def __init__(self):
        self.patient_data = PatientData()

# Main Application Class
class ApolloApp(HealthApp, QMainWindow):
    def __init__(self):
        HealthApp.__init__(self)  # Explicitly call HealthApp's __init__
        QMainWindow.__init__(self)  # Explicitly call QMainWindow's __init__
        self.setWindowTitle("Health Guardian - Disease Prediction System")
        self.setGeometry(100, 100, 800, 600)

        # Welcome Message
        welcome_text = QLabel("Welcome to MediPredict: Healing Starts Here\nFrom Symptoms to Answers, Instantly")
        welcome_text.setAlignment(Qt.AlignCenter)
        welcome_text.setWordWrap(True)

        # Loading an Image
        self.pic_label = QLabel()
        pixmap = QPixmap("path_to_your_image.jpg")  # Replace with your image path
        self.pic_label.setPixmap(pixmap)
        self.pic_label.setAlignment(Qt.AlignCenter)

        # Diseases
        self.diseases = [
            Disease("Common Cold", ["fever", "cough", "runny nose", "sore throat", "fatigue", "sneezing"], "Paracetamol", 3),
            Disease("Migraine", ["headache", "nausea", "sensitivity to light", "dizziness", "blurred vision", "neck stiffness"], "Ibuprofen", 2),
            Disease("Gastritis", ["stomach pain", "nausea", "vomiting", "bloating", "heartburn", "loss of appetite"], "Omeprazole", 5),
            Disease("Hypertension", ["headache", "dizziness", "chest pain", "blurred vision", "fatigue", "shortness of breath"], "Amlodipine", 7),
            Disease("Diabetes", ["fatigue", "thirst", "frequent urination", "blurred vision", "weight loss", "tingling hands"], "Metformin", 10),
            Disease("Asthma", ["wheezing", "shortness of breath", "cough", "chest tightness", "fatigue", "difficulty sleeping"], "Salbutamol", 5),
            Disease("Pneumonia", ["fever", "cough", "chest pain", "shortness of breath", "fatigue", "chills"], "Amoxicillin", 7),
            Disease("Bronchitis", ["cough", "mucus", "fatigue", "chest discomfort", "shortness of breath", "fever"], "Azithromycin", 5),
            Disease("Arthritis", ["joint pain", "stiffness", "swelling", "redness", "fatigue", "limited movement"], "Diclofenac", 10),
            Disease("Sinusitis", ["nasal congestion", "headache", "facial pain", "fever", "fatigue", "thick mucus"], "Amoxicillin", 5),
            Disease("Tonsillitis", ["sore throat", "fever", "swollen glands", "difficulty swallowing", "headache", "fatigue"], "Penicillin", 5),
            Disease("Urinary Tract Infection", ["burning urination", "frequent urination", "pelvic pain", "cloudy urine", "fever", "fatigue"], "Nitrofurantoin", 3),
            Disease("Hepatitis", ["jaundice", "fatigue", "abdominal pain", "nausea", "dark urine", "loss of appetite"], "Tenofovir", 14),
            Disease("Dengue", ["fever", "rash", "joint pain", "headache", "nausea", "muscle pain"], "Paracetamol", 7),
            Disease("Malaria", ["fever", "chills", "sweating", "headache", "fatigue", "muscle aches"], "Chloroquine", 7),
            Disease("Typhoid", ["fever", "weakness", "abdominal pain", "headache", "loss of appetite", "rash"], "Ciprofloxacin", 10),
            Disease("Tuberculosis", ["cough", "weight loss", "night sweats", "fever", "fatigue", "chest pain"], "Rifampicin", 30),
            Disease("Anemia", ["fatigue", "pale skin", "dizziness", "shortness of breath", "cold hands", "headache"], "Ferrous Sulfate", 14),
            Disease("Allergy", ["sneezing", "itchy eyes", "rash", "runny nose", "cough", "swelling"], "Cetirizine", 3),
            Disease("Conjunctivitis", ["red eyes", "itching", "discharge", "tearing", "gritty feeling", "swelling"], "Chloramphenicol", 3),
            Disease("Gout", ["joint pain", "swelling", "redness", "warmth", "stiffness", "fever"], "Allopurinol", 7),
            Disease("Eczema", ["itchy skin", "redness", "dry skin", "rash", "swelling", "crusting"], "Hydrocortisone", 7),
            Disease("Psoriasis", ["red patches", "scaling", "itching", "dry skin", "pain", "thickened nails"], "Methotrexate", 14),
            Disease("Acne", ["pimples", "redness", "oiliness", "blackheads", "pain", "scarring"], "Benzoyl Peroxide", 7),
            Disease("Cholecystitis", ["abdominal pain", "nausea", "fever", "vomiting", "back pain", "jaundice"], "Ceftriaxone", 7),
            Disease("Appendicitis", ["abdominal pain", "fever", "vomiting", "nausea", "loss of appetite", "diarrhea"], "Metronidazole", 5),
            Disease("Kidney Stones", ["flank pain", "blood in urine", "nausea", "vomiting", "frequent urination", "fever"], "Tamsulosin", 7),
            Disease("Peptic Ulcer", ["stomach pain", "bloating", "heartburn", "nausea", "vomiting", "weight loss"], "Pantoprazole", 7),
            Disease("Influenza", ["fever", "cough", "body aches", "fatigue", "headache", "sore throat"], "Oseltamivir", 5),
            Disease("Meningitis", ["fever", "headache", "stiff neck", "nausea", "rash", "sensitivity to light"], "Ceftriaxone", 7),
            Disease("Osteoporosis", ["back pain", "fractures", "stooped posture", "loss of height", "weakness", "bone pain"], "Alendronate", 14),
            Disease("Rheumatoid Arthritis", ["joint pain", "swelling", "fatigue", "stiffness", "fever", "weight loss"], "Methotrexate", 14),
            Disease("Irritable Bowel Syndrome", ["abdominal pain", "diarrhea", "constipation", "bloating", "mucus in stool", "fatigue"], "Loperamide", 7),
            Disease("Chronic Obstructive Pulmonary Disease", ["shortness of breath", "cough", "wheezing", "chest tightness", "fatigue", "mucus"], "Tiotropium", 10),
            Disease("Heart Failure", ["shortness of breath", "fatigue", "swelling", "rapid heartbeat", "cough", "dizziness"], "Furosemide", 14),
        ]

        # Doctors
        self.doctors = [
            Doctor("Dr. John Smith", "General Medicine"),
            Doctor("Dr. Priya Sharma", "Neurology"),
            Doctor("Dr. Anil Kumar", "Gastroenterology"),
            Doctor("Dr. Meena Patel", "Cardiology"),
            Doctor("Dr. Rajesh Gupta", "Endocrinology"),
            Doctor("Dr. Sanjay Verma", "Pulmonology"),
            Doctor("Dr. Kavita Rao", "Infectious Diseases"),
            Doctor("Dr. Vikram Singh", "Orthopedics"),
            Doctor("Dr. Neha Jain", "ENT"),
            Doctor("Dr. Amit Desai", "Urology"),
            Doctor("Dr. Suman Iyer", "Hepatology"),
            Doctor("Dr. Rohan Pillai", "Rheumatology"),
            Doctor("Dr. Lakshmi Nair", "Dermatology"),
            Doctor("Dr. Karan Mehra", "Ophthalmology"),
            Doctor("Dr. Pooja Shah", "Nephrology"),
            Doctor("Dr. Arjun Reddy", "General Surgery"),
            Doctor("Dr. Deepa Menon", "Pediatrics"),
            Doctor("Dr. Siddharth Bose", "Oncology"),
            Doctor("Dr. Ritu Agarwal", "Gynecology"),
            Doctor("Dr. Manoj Thomas", "Neurosurgery"),
            Doctor("Dr. Swati Kulkarni", "Psychiatry"),
            Doctor("Dr. Vinod Patil", "Hematology"),
            Doctor("Dr. Ananya Roy", "Allergy"),
            Doctor("Dr. Sameer Khan", "Pulmonology"),
            Doctor("Dr. Preeti Malhotra", "Endocrinology"),
            Doctor("Dr. Gaurav Chopra", "Cardiology"),
            Doctor("Dr. Shalini Tiwari", "Gastroenterology"),
            Doctor("Dr. Tarun Yadav", "Orthopedics"),
            Doctor("Dr. Rekha Joshi", "Neurology"),
            Doctor("Dr. Harish Menon", "Urology"),
            Doctor("Dr. Nisha Kapoor", "Dermatology"),
            Doctor("Dr. Vivek Nair", "Infectious Diseases"),
            Doctor("Dr. Kiran Bedi", "ENT"),
            Doctor("Dr. Ashok Rana", "General Medicine"),
            Doctor("Dr. Sonia Gupta", "Rheumatology"),
        ]

        self.init_ui(welcome_text)

    def init_ui(self, welcome_text):
        tabs = QTabWidget()
        main_layout = QVBoxLayout()
        main_layout.addWidget(welcome_text)
        main_layout.addWidget(self.pic_label)
        main_layout.addWidget(tabs)

        disease_tab = QWidget()
        tabs.addTab(disease_tab, "Disease Prediction")
        self.setup_disease_tab(disease_tab)

        appointment_tab = QWidget()
        tabs.addTab(appointment_tab, "Appointment Booking")
        self.setup_appointment_tab(appointment_tab)

        history_tab = QWidget()
        tabs.addTab(history_tab, "Patient History")
        self.setup_history_tab(history_tab)

        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

    def setup_disease_tab(self, tab):
        layout = QVBoxLayout()

        name_label = QLabel("Patient Name:")
        self.name_input = QLineEdit()
        layout.addWidget(name_label)
        layout.addWidget(self.name_input)

        symptoms_label = QLabel("Select Symptoms (CTRL+Click to select multiple):")
        self.symptoms_list = QListWidget()
        self.symptoms_list.addItems([
            "fever", "cough", "runny nose", "sore throat", "fatigue", "sneezing",
            "headache", "nausea", "stomach pain", "dizziness", "chest pain",
            "blurred vision", "shortness of breath", "joint pain", "redness",
            "itchy skin", "abdominal pain", "thick mucus", "muscle aches",
            "frequent urination", "rash", "swelling", "dry skin", "itching",
            "burning urination", "thirst"
        ])
        self.symptoms_list.setSelectionMode(QListWidget.MultiSelection)  # Enable multiple selection
        layout.addWidget(symptoms_label)
        layout.addWidget(self.symptoms_list)

        days_label = QLabel("Days Symptoms Persisted:")
        self.days_input = QLineEdit()
        layout.addWidget(days_label)
        layout.addWidget(self.days_input)

        self.result_display = QTextEdit()
        self.result_display.setReadOnly(True)
        layout.addWidget(self.result_display)

        predict_btn = QPushButton("Predict Disease")
        predict_btn.clicked.connect(self.predict_disease)
        layout.addWidget(predict_btn)

        clear_symptoms_btn = QPushButton("Clear Symptoms")
        clear_symptoms_btn.clicked.connect(self.clear_symptoms)
        layout.addWidget(clear_symptoms_btn)

        tab.setLayout(layout)

    def clear_symptoms(self):
        self.symptoms_list.clearSelection()
        self.result_display.append("Symptoms cleared.")

    def predict_disease(self):
        patient_name = self.name_input.text()
        user_symptoms = [item.text() for item in self.symptoms_list.selectedItems()]  # Get selected symptoms
        days = int(self.days_input.text() or 0)

        if not patient_name or not user_symptoms:
            QMessageBox.warning(self, "Error", "Please enter patient name and select symptoms.")
            return

        self.result_display.clear()
        predicted = False
        for disease in self.diseases:
            if disease.predict(user_symptoms):
                self.result_display.append(f"Predicted Disease: {disease.name}")
                self.result_display.append(disease.get_recommendation(days))
                self.patient_data.add_disease(patient_name, disease.name)
                predicted = True
                break

        if not predicted:
            self.result_display.append("No disease matched. Consult a doctor for further evaluation.")

    def setup_appointment_tab(self, tab):
        layout = QVBoxLayout()

        name_label = QLabel("Patient Name:")
        self.app_name_input = QLineEdit()
        layout.addWidget(name_label)
        layout.addWidget(self.app_name_input)

        specialty_label = QLabel("Select Specialty:")
        self.specialty_combo = QComboBox()
        specialties = list(set(doc.specialty for doc in self.doctors))
        self.specialty_combo.addItems(specialties)
        layout.addWidget(specialty_label)
        layout.addWidget(self.specialty_combo)

        doctor_label = QLabel("Select Doctor:")
        self.doctor_combo = QComboBox()
        self.specialty_combo.currentTextChanged.connect(self.update_doctors)
        layout.addWidget(doctor_label)
        layout.addWidget(self.doctor_combo)

        date_label = QLabel("Appointment Date (YYYY-MM-DD):")
        self.date_input = QLineEdit()
        time_label = QLabel("Appointment Time (HH:MM):")
        self.time_input = QLineEdit()
        layout.addWidget(date_label)
        layout.addWidget(self.date_input)
        layout.addWidget(time_label)
        layout.addWidget(self.time_input)

        book_btn = QPushButton("Book Appointment")
        book_btn.clicked.connect(self.book_appointment)
        layout.addWidget(book_btn)

        tab.setLayout(layout)
        self.update_doctors(specialties[0])

    def update_doctors(self, specialty):
        self.doctor_combo.clear()
        doctors = [doc.name for doc in self.doctors if doc.specialty == specialty]
        self.doctor_combo.addItems(doctors)

    def book_appointment(self):
        patient_name = self.app_name_input.text()
        doctor = self.doctor_combo.currentText()
        date = self.date_input.text()
        time = self.time_input.text()

        if not all([patient_name, doctor, date, time]):
            QMessageBox.warning(self, "Error", "Please fill all fields.")
            return

        try:
            appointment_date = datetime.strptime(date, "%Y-%m-%d")
            current_date = datetime.now()
            if appointment_date <= current_date:
                QMessageBox.warning(self, "Error", "Appointment date must be in the future.")
                return
        except ValueError:
            QMessageBox.warning(self, "Error", "Invalid date format. Use YYYY-MM-DD.")
            return

        try:
            datetime.strptime(time, "%H:%M")
        except ValueError:
            QMessageBox.warning(self, "Error", "Invalid time format. Use HH:MM.")
            return

        self.patient_data.add_appointment(patient_name, doctor, date, time)
        QMessageBox.information(self, "Success", f"Appointment booked with {doctor} on {date} at {time}.")

    def setup_history_tab(self, tab):
        layout = QVBoxLayout()

        name_label = QLabel("Patient Name:")
        self.hist_name_input = QLineEdit()
        layout.addWidget(name_label)
        layout.addWidget(self.hist_name_input)

        self.history_table = QTableWidget()
        self.history_table.setColumnCount(6)
        self.history_table.setHorizontalHeaderLabels(["Patient", "Disease", "Date", "Doctor", "App. Date", "App. Time"])
        layout.addWidget(self.history_table)

        view_btn = QPushButton("View History")
        view_btn.clicked.connect(self.view_history)
        layout.addWidget(view_btn)

        tab.setLayout(layout)

    def view_history(self):
        patient_name = self.hist_name_input.text()
        if not patient_name:
            QMessageBox.warning(self, "Error", "Please enter patient name.")
            return

        history = self.patient_data.get_history(patient_name)
        self.history_table.setRowCount(len(history))
        for row, record in enumerate(history):
            for col, value in enumerate(record):
                self.history_table.setItem(row, col, QTableWidgetItem(value))

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ApolloApp()
    window.show()
    sys.exit(app.exec_())