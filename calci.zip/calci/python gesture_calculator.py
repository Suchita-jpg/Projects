import cv2
import numpy as np
import track_hand as htm
import time

# Camera Setup
wCam, hCam = 1280, 720
cap = cv2.VideoCapture(0)
cap.set(3, wCam)
cap.set(4, hCam)

# Hand Detector
detector = htm.handDetector(detectionCon=0.7)

# Variables
expression = ""
last_input_time = 0
debounce_delay = 1  # seconds (prevents fast inputs)
result = ""
prev_gesture = None  # To prevent duplicate inputs

def get_gesture(fingers):
    """
    Maps detected finger positions to corresponding calculator operations.
    """
    count = fingers.count(1)

    # Numbers 0-5
    if fingers == [0, 0, 0, 0, 0]: return None  # No gesture detected
    elif fingers == [0, 1, 0, 0, 0]: return "1"
    elif fingers == [0, 1, 1, 0, 0]: return "2"
    elif fingers == [0, 1, 1, 1, 0]: return "3"
    elif fingers == [0, 1, 1, 1, 1]: return "4"
    elif fingers == [1, 1, 1, 1, 1]: return "5"

    # Operators
    elif fingers == [1, 0, 0, 0, 1]: return "+"
    elif fingers == [0, 1, 1, 0, 1]: return "-"
    elif fingers == [1, 1, 0, 0, 1]: return "*"
    elif fingers == [0, 0, 0, 0, 1]: return "/"

    # Special Actions
    elif fingers == [1, 0, 0, 0, 0]: return "="  # Evaluate
    elif fingers == [0, 0, 1, 0, 0]: return "C"  # Clear

    return None  # No valid gesture detected

while True:
    success, img = cap.read()
    img = detector.findHands(img)
    lmList, bbox = detector.findPosition(img)

    fingers = detector.fingersUp() if lmList else [0, 0, 0, 0, 0]
    gesture = get_gesture(fingers)

    # Process input only if it's valid, different from the previous input, and debounce delay has passed
    current_time = time.time()
    if gesture and gesture not in [None, "0"] and gesture != prev_gesture:  # Ignore unwanted zeros & repeats
        if (current_time - last_input_time) > debounce_delay:
            if gesture == "=":
                try:
                    result = str(eval(expression))
                    expression = result
                except:
                    result = "Error"
                    expression = ""
            elif gesture == "C":
                expression = ""
                result = ""
            else:
                expression += gesture  # Append only valid inputs
            prev_gesture = gesture  # Store previous gesture to avoid duplicates
            last_input_time = current_time  # Update last input time

    # Display expression and result
    cv2.putText(img, "Expr: " + expression, (50, 100),
                cv2.FONT_HERSHEY_SIMPLEX, 1.5, (255, 255, 255), 3)
    cv2.putText(img, "Result: " + result, (50, 170),
                cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 255, 0), 3)

    # Show video feed
    cv2.imshow("Gesture Calculator", img)

    # Exit program when 'q' or 'ESC' key is pressed
    key = cv2.waitKey(1) & 0xFF
    if key == ord('q') or key == 27:
        break

# Properly release the camera and close all windows
cap.release()
cv2.destroyAllWindows()
cv2.waitKey(1)  # Extra wait to ensure proper closure
